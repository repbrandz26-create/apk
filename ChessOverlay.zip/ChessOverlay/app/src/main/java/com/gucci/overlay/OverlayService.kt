package com.gucci.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.util.DisplayMetrics
import android.util.Log
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.core.content.IntentCompat

class OverlayService : Service() {

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val ACTION_STOP = "stop"
        private const val TAG = "ChessOverlay"
    }

    private val main = Handler(Looper.getMainLooper())
    private var worker: HandlerThread? = null
    private var bg: Handler? = null
    private var wm: WindowManager? = null
    private var web: WebView? = null
    private var server: AssetServer? = null
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vdisplay: VirtualDisplay? = null
    private var capW = 0
    private var capH = 0
    private var lastBmp: Bitmap? = null
    private var lastFrameAt = 0L
    private var frames = 0

    @Volatile private var running = false
    @Volatile private var rebaselineAt = 0L

    // Vision state, touched only on the vision thread.
    private var board: Board? = null
    private var tracking = false
    private var wasStart = false
    private var mid = 128
    private var baseline: IntArray? = null
    private var phase = 0
    private var phaseSince = 0L
    private var prevSig: IntArray? = null
    private var lastDetect = 0L
    private var lastStatus = ""

    inner class Bridge {
        @JavascriptInterface
        fun arrowsChanged() { rebaselineAt = SystemClock.uptimeMillis() + 500 }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (running) return START_NOT_STICKY
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val n = notification()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
        running = true
        try {
            startCapture(code, data)
            startOverlay()
        } catch (e: Exception) {
            Log.e(TAG, "start failed", e)
            stopSelf()
            return START_NOT_STICKY
        }
        worker = HandlerThread("vision").also { it.start() }
        bg = Handler(worker!!.looper)
        bg?.postDelayed(tick, 3000)
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        val wmgr = getSystemService(WINDOW_SERVICE) as WindowManager
        val bounds: Rect = if (Build.VERSION.SDK_INT >= 30) {
            wmgr.maximumWindowMetrics.bounds
        } else {
            val dm = DisplayMetrics()
            @Suppress("DEPRECATION") wmgr.defaultDisplay.getRealMetrics(dm)
            Rect(0, 0, dm.widthPixels, dm.heightPixels)
        }
        capW = bounds.width() / 2
        capH = bounds.height() / 2
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)
        val r = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)
        vdisplay = proj.createVirtualDisplay(
            "chess-capture", capW, capH, resources.displayMetrics.densityDpi / 2,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, null
        )
        projection = proj
        reader = r
    }

    private fun startOverlay() {
        val srv = AssetServer(this).also { it.start() }
        server = srv
        val wmgr = getSystemService(WINDOW_SERVICE) as WindowManager
        val v = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("http://127.0.0.1:${srv.port}/overlay.html")
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        wmgr.addView(v, lp)
        wm = wmgr
        web = v
    }

    private fun js(code: String) { main.post { web?.evaluateJavascript(code, null) } }

    private fun status(text: String) {
        if (text == lastStatus) return
        lastStatus = text
        js("setStatus('${text.replace("'", "")}')")
    }

    private val tick = object : Runnable {
        override fun run() {
            if (!running) return
            try { step() } catch (e: Exception) { Log.e(TAG, "tick", e) }
            bg?.postDelayed(this, 250)
        }
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            try {
                val plane = img.planes[0]
                val rowPad = plane.rowStride - plane.pixelStride * img.width
                val full = Bitmap.createBitmap(img.width + rowPad / plane.pixelStride, img.height, Bitmap.Config.ARGB_8888)
                full.copyPixelsFromBuffer(plane.buffer)
                lastBmp = if (rowPad == 0) full else Bitmap.createBitmap(full, 0, 0, img.width, img.height)
                lastFrameAt = SystemClock.uptimeMillis()
                frames++
            } finally {
                img.close()
            }
        }
        return lastBmp
    }

    private fun step() {
        val bmp = grab() ?: return
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val now = SystemClock.uptimeMillis()

        if (!tracking) {
            if (now - lastDetect > 600) { lastDetect = now; tryStart(px, w, h) }
            return
        }
        val b = board ?: return
        val sig = BoardVision.signature(px, w, b)
        if (phase == 0) {
            val rb = rebaselineAt
            if (rb != 0L) {
                if (now >= rb) { baseline = sig; rebaselineAt = 0 }
                return
            }
            val base = baseline
            if (base == null) { baseline = sig; return }
            if (BoardVision.diff(sig, base) > 14) {
                phase = 1; phaseSince = now; prevSig = sig
                js("clearArrows()")
            }
        } else {
            val settled = BoardVision.diff(sig, prevSig ?: sig) <= 4
            prevSig = sig
            val fresh = lastFrameAt > phaseSince + 100
            if ((now - phaseSince > 400 && settled && fresh) || now - phaseSince > 3500) {
                analyze(px, w, h)
                phase = 0
                rebaselineAt = SystemClock.uptimeMillis() + 600
            }
        }
    }

    private fun tryStart(px: IntArray, w: Int, h: Int) {
        val b = BoardVision.detect(px, w, h)
        if (b == null) {
            fun hx(x: Int, y: Int) = String.format("%06X", px[y * w + x] and 0xFFFFFF)
            status("Waiting… ${w}x$h f=$frames ${BoardVision.diag} " +
                hx(w / 4, h * 6 / 10) + " " + hx(w * 3 / 4, h * 6 / 10) + " " + hx(w / 2, h / 2))
            return
        }
        val f = BoardVision.features(px, w, b)
        val s = BoardVision.startCheck(f)
        if (s == null) { status("Board found, waiting for start position…"); return }
        startNew(b, s, f)
    }

    private fun startNew(b: Board, s: StartInfo, f: Feat) {
        board = b
        mid = s.mid
        tracking = true
        wasStart = true
        phase = 0
        baseline = null
        rebaselineAt = SystemClock.uptimeMillis() + 800
        Log.i(TAG, "board ${b.left},${b.top},${b.size} whiteBottom=${s.whiteBottom}")
        js(
            "setBoard(${b.left.toFloat() / capW}, ${b.top.toFloat() / capH}, ${b.size.toFloat() / capW}, ${b.size.toFloat() / capH});" +
                "newGame(${s.whiteBottom}, '${BoardVision.map(f, s.mid)}')"
        )
    }

    private fun analyze(px: IntArray, w: Int, h: Int) {
        val nb = BoardVision.detect(px, w, h)
        if (nb != null) {
            val f2 = BoardVision.features(px, w, nb)
            val s2 = BoardVision.startCheck(f2)
            if (s2 != null && !wasStart) { startNew(nb, s2, f2); return }
        }
        val b = board ?: return
        val f = BoardVision.features(px, w, b)
        wasStart = BoardVision.startCheck(f) != null
        js("onMap('${BoardVision.map(f, mid)}')")
    }

    private fun notification(): Notification {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("overlay", "Overlay", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE
        )
        val action = Notification.Action.Builder(
            Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stop
        ).build()
        return Notification.Builder(this, "overlay")
            .setContentTitle("Chess Overlay running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .addAction(action)
            .build()
    }

    override fun onDestroy() {
        running = false
        bg?.removeCallbacksAndMessages(null)
        worker?.quitSafely()
        try { vdisplay?.release() } catch (_: Exception) {}
        try { reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        web?.let { try { wm?.removeView(it) } catch (_: Exception) {}; it.destroy() }
        web = null
        server?.stop()
        super.onDestroy()
    }
}
