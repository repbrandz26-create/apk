package com.gucci.overlay

import kotlin.math.abs

class Board(val left: Int, val top: Int, val size: Int)
class StartInfo(val whiteBottom: Boolean, val mid: Int)
class Feat(val dev: FloatArray, val lum: IntArray)

/** Pixel-level board finding and per-square occupancy reading. No templates needed. */
object BoardVision {

    private const val OCC = 0.08f
    @Volatile var diag = ""

    private fun dist(a: Int, b: Int): Int =
        abs(((a shr 16) and 255) - ((b shr 16) and 255)) +
            abs(((a shr 8) and 255) - ((b shr 8) and 255)) +
            abs((a and 255) - (b and 255))

    private fun lum(c: Int): Int =
        (((c shr 16) and 255) * 3 + ((c shr 8) and 255) * 6 + (c and 255)) / 10

    /** Run-length encode a line of pixels: [start, length, color]. Runs shorter than 4px (edge blur) merge backwards. */
    private fun runs(n: Int, at: (Int) -> Int): List<IntArray> {
        val out = ArrayList<IntArray>()
        var start = 0
        var ref = at(0)
        for (i in 1 until n) {
            val c = at(i)
            if (dist(c, ref) > 30) {
                val len = i - start
                if (len < 4 && out.isNotEmpty()) out.last()[1] += len else out.add(intArrayOf(start, len, ref))
                start = i
                ref = c
            }
        }
        out.add(intArrayOf(start, n - start, ref))
        return out
    }

    /** Finds the board while it shows the starting position (ranks 3-6 empty = 4 flat rows of 8 alternating squares). */
    fun detect(px: IntArray, w: Int, h: Int): Board? {
        val votes = HashMap<Int, IntArray>()
        var y = 0
        while (y < h) {
            val yy = y
            val rs = runs(w) { px[yy * w + it] }
            for (i in 0..rs.size - 8) {
                val len = rs[i][1]
                if (len < w / 24 || len > w / 8 + 3) continue
                var ok = true
                for (k in 0 until 8) {
                    val r = rs[i + k]
                    if (abs(r[1] - len) > maxOf(3, len / 8)) { ok = false; break }
                    if (k > 0 && dist(r[2], rs[i + k - 1][2]) < 12) { ok = false; break }
                    if (k > 1 && dist(r[2], rs[i + k - 2][2]) > 45) { ok = false; break }
                }
                if (!ok) continue
                val sq = (rs[i + 7][0] + rs[i + 7][1] - rs[i][0]) / 8
                val key = (rs[i][0] / 4) * 1000 + sq / 3
                val v = votes.getOrPut(key) { IntArray(3) }
                v[0]++; v[1] += rs[i][0]; v[2] += sq
                break
            }
            y += 2
        }
        val best = votes.values.maxByOrNull { it[0] }
        if (best == null || best[0] < 20) { diag = "rows=" + (best?.get(0) ?: 0); return null }
        val x0 = best[1] / best[0]
        val sq = best[2] / best[0]
        if (sq < 8) { diag = "sq=$sq"; return null }

        val tops = ArrayList<Int>()
        for (f in 1..6) {
            val x = x0 + f * sq + sq / 2
            if (x >= w) continue
            val rs = runs(h) { px[it * w + x] }
            for (i in 0..rs.size - 4) {
                var ok = true
                for (k in 0 until 4) {
                    val r = rs[i + k]
                    if (abs(r[1] - sq) > maxOf(3, sq / 8)) { ok = false; break }
                    if (k > 0 && dist(r[2], rs[i + k - 1][2]) < 12) { ok = false; break }
                }
                if (ok) { tops.add(rs[i][0] - 2 * sq); break }
            }
        }
        diag = "x0=$x0 sq=$sq tops=${tops.size}"
        if (tops.size < 3) return null
        tops.sort()
        val med = tops[tops.size / 2]
        if (tops.count { abs(it - med) <= sq / 6 } < 3) return null
        if (med < 0 || med + 8 * sq > h || x0 + 8 * sq > w) return null
        return Board(x0, med, 8 * sq)
    }

    fun features(px: IntArray, w: Int, b: Board): Feat {
        val sq = b.size / 8
        val dev = FloatArray(64)
        val lm = IntArray(64)
        for (r in 0..7) for (c in 0..7) {
            val x0 = b.left + c * sq
            val y0 = b.top + r * sq
            fun p(fx: Double, fy: Double): Int = px[(y0 + (fy * sq).toInt()) * w + (x0 + (fx * sq).toInt())]
            val corners = intArrayOf(p(.15, .15), p(.85, .15), p(.15, .85), p(.85, .85))
            var bg = corners[1]
            var bestN = -1
            for (i in 0..3) {
                var n = 0
                for (j in 0..3) if (dist(corners[i], corners[j]) < 24) n++
                if (n > bestN) { bestN = n; bg = corners[i] }
            }
            var cnt = 0
            for (iy in 0 until 10) for (ix in 0 until 10) {
                if (dist(p(.2 + .06 * ix + .03, .2 + .06 * iy + .03), bg) > 70) cnt++
            }
            dev[r * 8 + c] = cnt / 100f
            var s = 0
            for (iy in 0 until 5) for (ix in 0 until 5) s += lum(p(.3 + .08 * ix + .04, .3 + .08 * iy + .04))
            lm[r * 8 + c] = s / 25
        }
        return Feat(dev, lm)
    }

    /** Starting layout: rows 0,1,6,7 full, rows 2-5 empty, top and bottom armies clearly different in brightness. */
    fun startCheck(f: Feat): StartInfo? {
        for (i in 0 until 64) {
            val r = i / 8
            if ((r <= 1 || r >= 6) != (f.dev[i] > OCC)) return null
        }
        var top = 0
        var bot = 0
        for (i in 0 until 16) top += f.lum[i]
        for (i in 48 until 64) bot += f.lum[i]
        top /= 16; bot /= 16
        if (abs(top - bot) < 50) return null
        val mid = (top + bot) / 2
        var bad = 0
        for (i in 0 until 16) if ((f.lum[i] > mid) != (top > mid)) bad++
        for (i in 48 until 64) if ((f.lum[i] > mid) != (bot > mid)) bad++
        if (bad > 3) return null
        return StartInfo(bot > top, mid)
    }

    /** 64 chars, screen order top-left first: 'w' white piece, 'b' black piece, '.' empty. */
    fun map(f: Feat, mid: Int): String {
        val sb = StringBuilder(64)
        for (i in 0 until 64) sb.append(if (f.dev[i] <= OCC) '.' else if (f.lum[i] > mid) 'w' else 'b')
        return sb.toString()
    }

    /** Coarse pixel fingerprint of the board, used only to notice that something changed. */
    fun signature(px: IntArray, w: Int, b: Board): IntArray {
        val sq = b.size / 8
        val out = IntArray(1024)
        var k = 0
        for (r in 0..7) for (c in 0..7) for (iy in 0..3) for (ix in 0..3) {
            val x = b.left + c * sq + ((ix * .25 + .125) * sq).toInt()
            val y = b.top + r * sq + ((iy * .25 + .125) * sq).toInt()
            out[k++] = px[y * w + x]
        }
        return out
    }

    fun diff(a: IntArray, b: IntArray): Int {
        var n = 0
        for (i in a.indices) if (dist(a[i], b[i]) > 60) n++
        return n
    }
}
