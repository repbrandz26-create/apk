package com.gucci.overlay

import android.content.Context
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Serves APK assets on 127.0.0.1 so the WebView page can use Workers and WASM fetches. */
class AssetServer(private val ctx: Context) {
    private val server = ServerSocket(0, 16, InetAddress.getByName("127.0.0.1"))
    val port: Int get() = server.localPort

    fun start() {
        thread(isDaemon = true) {
            while (true) {
                val s = try { server.accept() } catch (e: Exception) { break }
                thread(isDaemon = true) { handle(s) }
            }
        }
    }

    fun stop() { try { server.close() } catch (_: Exception) {} }

    private fun mime(p: String) = when {
        p.endsWith(".html") -> "text/html"
        p.endsWith(".js") -> "text/javascript"
        p.endsWith(".wasm") -> "application/wasm"
        else -> "application/octet-stream"
    }

    private fun handle(s: Socket) {
        try {
            s.use {
                val reader = it.getInputStream().bufferedReader()
                val line = reader.readLine() ?: return
                while (true) { val h = reader.readLine() ?: break; if (h.isEmpty()) break }
                var path = line.split(" ").getOrNull(1)?.substringBefore("?")?.trimStart('/') ?: ""
                if (path.isEmpty()) path = "overlay.html"
                val out = it.getOutputStream()
                try {
                    ctx.assets.open(path).use { input ->
                        out.write("HTTP/1.1 200 OK\r\nContent-Type: ${mime(path)}\r\nCache-Control: no-store\r\nConnection: close\r\n\r\n".toByteArray())
                        input.copyTo(out, 65536)
                    }
                } catch (e: java.io.FileNotFoundException) {
                    out.write("HTTP/1.1 404 Not Found\r\nConnection: close\r\n\r\n".toByteArray())
                }
                out.flush()
            }
        } catch (_: Exception) {}
    }
}
