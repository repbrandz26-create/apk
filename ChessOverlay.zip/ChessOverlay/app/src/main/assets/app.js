// Overlay brain: tracks the game from occupancy maps, runs Stockfish, draws the best move.
const canvas = document.getElementById('c');
const ctx = canvas.getContext('2d');
const stEl = document.getElementById('st');

let game = null, whiteBottom = true;
let board = { l: 0, t: 0, sw: 1, sh: 1 };      // fractions of the screen
let arrows = [], lastBest = null;
let engine = null, engineReady = false, searching = false, wantThink = false, searchFen = '';

function setStatus(t) { stEl.textContent = t; stEl.style.display = t ? 'block' : 'none'; }
function notify() { try { Android.arrowsChanged(); } catch (e) {} }

// ---------- drawing ----------
function resize() {
  canvas.width = innerWidth * devicePixelRatio;
  canvas.height = innerHeight * devicePixelRatio;
  render();
}
function drawArrow(x1, y1, x2, y2) {
  const W = canvas.width, H = canvas.height;
  const ax = x1 * W, ay = y1 * H, bx = x2 * W, by = y2 * H;
  const ang = Math.atan2(by - ay, bx - ax);
  const sq = board.sw * W / 8, head = sq * 0.5;
  ctx.strokeStyle = ctx.fillStyle = 'rgba(0,230,90,0.8)';
  ctx.lineWidth = sq * 0.2;
  ctx.lineCap = 'round';
  ctx.beginPath(); ctx.moveTo(ax, ay);
  ctx.lineTo(bx - Math.cos(ang) * head * 0.6, by - Math.sin(ang) * head * 0.6); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(bx, by);
  ctx.lineTo(bx - head * Math.cos(ang - 0.45), by - head * Math.sin(ang - 0.45));
  ctx.lineTo(bx - head * Math.cos(ang + 0.45), by - head * Math.sin(ang + 0.45));
  ctx.closePath(); ctx.fill();
}
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  arrows.forEach(a => drawArrow(a[0], a[1], a[2], a[3]));
}
function clearArrows() { arrows = []; render(); notify(); }
function setBoard(l, t, sw, sh) { board = { l, t, sw, sh }; }

function sqXY(sq) {
  const file = sq.charCodeAt(0) - 97, rank = parseInt(sq[1], 10) - 1;
  const r = whiteBottom ? 7 - rank : rank, c = whiteBottom ? file : 7 - file;
  return [board.l + (c + 0.5) / 8 * board.sw, board.t + (r + 0.5) / 8 * board.sh];
}
function showBest() {
  if (!lastBest) return;
  const a = sqXY(lastBest.slice(0, 2)), b = sqXY(lastBest.slice(2, 4));
  arrows = [[a[0], a[1], b[0], b[1]]];
  render(); notify();
}

// ---------- tracking ----------
function mapOf(g) {
  const b = g.board(); let s = '';
  for (let r = 0; r < 8; r++) for (let c = 0; c < 8; c++) {
    const cell = whiteBottom ? b[r][c] : b[7 - r][7 - c];
    s += cell ? cell.color : '.';
  }
  return s;
}
function tryMoves(m) {
  const first = game.moves({ verbose: true });
  for (const a of first) {
    game.move({ from: a.from, to: a.to, promotion: 'q' });
    if (mapOf(game) === m) return true;
    game.undo();
  }
  for (const a of first) {                       // two moves happened between captures
    game.move({ from: a.from, to: a.to, promotion: 'q' });
    for (const b of game.moves({ verbose: true })) {
      game.move({ from: b.from, to: b.to, promotion: 'q' });
      if (mapOf(game) === m) return true;
      game.undo();
    }
    game.undo();
  }
  return false;
}
function myTurn() { return game && game.turn() === (whiteBottom ? 'w' : 'b'); }

function newGame(wb, m) {
  game = new Chess(); whiteBottom = wb; lastBest = null; arrows = [];
  render(); notify();
  stateText = 'new game, ' + (wb ? 'white' : 'black') + ' at bottom'; refresh();
  think();
}
function onMap(m) {
  if (!game) return;
  if (m === mapOf(game)) { if (lastBest && !searching) showBest(); else think(); return; }
  if (tryMoves(m)) { lastBest = null; arrows = []; render(); think(); }
  else if (lastBest) showBest();                 // unreadable frame (menu, selection hint...), keep last advice
}

// ---------- engine ----------
let engineKind = '', stateText = '';
function refresh() { setStatus((engineKind ? 'SF ' + engineKind : 'No engine') + ' · ' + stateText); }
function think() {
  if (!engineReady || !game || game.game_over() || !myTurn()) return;
  if (searching) { wantThink = true; engine.postMessage('stop'); return; }
  searching = true; searchFen = game.fen();
  stateText = 'thinking…'; refresh();
  engine.postMessage('position fen ' + searchFen);
  engine.postMessage('go movetime 2500');
}
function onEngine(line) {
  if (line.startsWith('info') && searching) {
    const m = /depth (\d+).*?score (cp|mate) (-?\d+)/.exec(line);
    if (m) { stateText = 'd' + m[1] + ' ' + (m[2] === 'cp' ? (m[3] / 100).toFixed(2) : '#' + m[3]); refresh(); }
    return;
  }
  if (!line.startsWith('bestmove')) return;
  searching = false;
  if (wantThink) { wantThink = false; think(); return; }
  const mv = line.split(' ')[1];
  if (mv && mv !== '(none)' && game && game.fen() === searchFen) {
    lastBest = mv; stateText = 'best ' + mv; refresh(); showBest();
  }
}
function adopt(w, kind) {
  const old = engine;
  engine = w; engineReady = true; engineKind = kind; searching = false; wantThink = false;
  if (old) { try { old.terminate(); } catch (e) {} }
  stateText = 'ready'; refresh(); think();
  if (kind === 'lite') startEngine('full', true);   // upgrade to the full network in the background
}
function startEngine(kind, background) {
  if (!background) { stateText = 'loading…'; engineKind = kind; refresh(); }
  let w;
  try { w = new Worker('sf-' + kind + '.js'); } catch (e) { stateText = 'worker error'; refresh(); return; }
  let ok = false;
  const fail = () => {
    if (ok) return;
    try { w.terminate(); } catch (e) {}
    if (!background) { stateText = 'engine failed'; refresh(); }
  };
  w.onerror = fail;
  w.onmessage = e => {
    const l = e.data;
    if (typeof l !== 'string') return;
    if (l === 'uciok') {
      w.postMessage('setoption name Hash value ' + (kind === 'full' ? 64 : 32));
      w.postMessage('isready');
    } else if (l === 'readyok') {
      if (!ok) { ok = true; adopt(w, kind); }
    } else if (w === engine) onEngine(l);
  };
  w.postMessage('uci');
  setTimeout(fail, kind === 'full' ? 120000 : 30000);
}

addEventListener('resize', resize);
resize();
startEngine('lite', false);
