plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.gucci.overlay"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.gucci.overlay"
        minSdk = 26
        targetSdk = 34
        versionCode = 2
        versionName = "0.2"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("androidx.core:core-ktx:1.13.1") }

// Downloads Stockfish 19 (full + lite, single-threaded WASM) from npm at build time.
val fetchEngine by tasks.registering {
    doLast {
        val assets = file("src/main/assets")
        if (File(assets, "sf-full.wasm").exists() && File(assets, "sf-lite.wasm").exists()) return@doLast
        val work = layout.buildDirectory.dir("sf").get().asFile
        work.mkdirs()
        project.exec { workingDir = work; commandLine("npm", "pack", "stockfish@19.0.1") }
        project.exec { workingDir = work; commandLine("tar", "xzf", "stockfish-19.0.1.tgz") }
        val bin = File(work, "package/bin")
        for ((src, dst) in listOf("stockfish-19-single" to "sf-full", "stockfish-19-lite-single" to "sf-lite")) {
            for (ext in listOf("js", "wasm")) {
                File(bin, "$src.$ext").copyTo(File(assets, "$dst.$ext"), overwrite = true)
            }
        }
    }
}
tasks.matching { it.name == "preBuild" }.configureEach { dependsOn(fetchEngine) }
